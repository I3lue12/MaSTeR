﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Profile.flyerID == 0)
            Response.Redirect("Login.aspx");

        //if (Request.Cookies["flyerID"] == null)
        //    Response.Redirect("Login.aspx");
        else
        {
            SqlConnection dbConnection = new SqlConnection(ConnectionString.Value);
            dbConnection.Open();

            try {

                //placed .value on cookie for sqlCommand to make a query.
                //SqlCommand sqlCommand = new SqlCommand( "SELECT flyerID, first, last FROM FrequentFlyers WHERE flyerID = " + Request.Cookies["flyerID"].Value, dbConnection);
                //made a profile for the sql command
                SqlCommand sqlCommand = new SqlCommand("SELECT flyerID, first, last FROM FrequentFlyers WHERE flyerID = " + Profile.flyerID, dbConnection);
                SqlDataReader userInfo = sqlCommand.ExecuteReader();
                if (userInfo.Read()) {
                    flyerIDValue.Text = userInfo["flyerID"].ToString();
                    firstName.Text = userInfo["first"].ToString();
                    lastName.Text = userInfo["last"].ToString();
                }
                userInfo.Close();
            } catch (SqlException exception) {
                Response.Write("<p>Error code "
                    + exception.Number + ": "
                    + exception.Message + "</p>");
            }
            dbConnection.Close();
        }
    }

    protected void logout_Click(object sender, EventArgs e)
    {
        Response.Cookies["flyerID"].Expires = DateTime.Now.AddDays(-1);
        Response.Redirect("Login.aspx");
    }
}
