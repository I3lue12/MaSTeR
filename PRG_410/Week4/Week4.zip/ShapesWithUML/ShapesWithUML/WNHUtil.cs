﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShapesWithUML
{
    public class WNHUtil
    {
    }
    public class Width
    {
        private double mValue;
        public double Value
        {
            get { return mValue; }
            set { mValue = value; }
        }
    }
    public class Height
    {
        private double mHeight;
        public double Value
        {
            get { return mHeight; }
            set { mHeight = value; }
        }
    }
}
